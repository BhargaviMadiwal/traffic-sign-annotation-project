# Traffic Sign Annotation Project
**Tech:** LabelImg, Excel

## Classes
Stop, No_Entry, Speed_Limit, Turn_Left

## Workflow
1. Open a traffic-sign image in LabelImg.
2. Use Create RectBox to draw a bounding box around each sign.
3. Assign the correct sign label.
4. Save annotations in Pascal VOC XML format.
5. Review bounding boxes and labels for accuracy.
6. Maintain annotation details in Excel.

## Included
- 5 clean traffic-sign practice images
- 5 Pascal VOC XML annotation files
- Excel annotation record
- README

## Resume Description
**Traffic Sign Annotation Project**  
**Tech:** LabelImg, Excel
- Annotated traffic signs using bounding boxes.
- Identified Stop, No Entry, Speed Limit and Turn signs.
- Checked annotations for accuracy and consistency.
- Corrected incorrect or missing labels.
